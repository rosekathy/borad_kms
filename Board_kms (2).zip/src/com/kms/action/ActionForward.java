package com.kms.action;

public class ActionForward {

	private boolean check;
	//check - true forward
	//check - false redirect
	private String path;
	//forwarding 또는 redirect의 경로
	
	
	public boolean isCheck() {
		return check;
	}
	public void setCheck(boolean check) {
		this.check = check;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	
	
}
