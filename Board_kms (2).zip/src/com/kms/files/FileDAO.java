package com.kms.files;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.kms.util.DBConnector;

public class FileDAO {

	public int insert(FileDTO fileDTO) throws Exception{
		Connection con = DBConnector.getConnect();
		String sql ="insert into files(fnum,num,oname,fname) values (files_seq.nextval,?,?,?)";
		
		PreparedStatement st = con.prepareStatement(sql);
		st.setInt(1, fileDTO.getNum());
		st.setString(2, fileDTO.getOname());
		st.setString(3, fileDTO.getFname());

		int result = st.executeUpdate();
		
		DBConnector.disConnect(st, con);
		return result;
	}
	
	public ArrayList<FileDTO> selectOne(int num) throws Exception{
		
		Connection con = DBConnector.getConnect();
		String sql = "select * from files where num=?";
		
		PreparedStatement st = con.prepareStatement(sql);
		st.setInt(1, num);
		
		ResultSet rs = st.executeQuery();
		
		
		 ArrayList<FileDTO> ar = new ArrayList<FileDTO>();
		 
		 while(rs.next()) { 
			 FileDTO fileDTO = new FileDTO();
		 	fileDTO.setFnum(rs.getInt("fnum")); 
		 	fileDTO.setNum(rs.getInt("num"));
		 	fileDTO.setOname(rs.getString("oname"));
		 	fileDTO.setFname(rs.getString("fname")); 
		 	ar.add(fileDTO);
		  }
		
		DBConnector.disConnect(rs, st, con);
		return ar;
	}
	
}
