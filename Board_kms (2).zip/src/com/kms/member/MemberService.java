package com.kms.member;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.kms.action.ActionForward;

public class MemberService {

	MemberDAO memberDAO;

	public MemberService() {
		memberDAO = new MemberDAO();
	}

	public ActionForward join(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward actionForward = new ActionForward();

		String method = request.getMethod();

		if (method.equals("POST")) {
			MemberDTO memberDTO = new MemberDTO();
			memberDTO.setId(request.getParameter("id"));
			memberDTO.setPw(request.getParameter("pw"));
			memberDTO.setName(request.getParameter("name"));
			memberDTO.setAge(Integer.parseInt(request.getParameter("age")));
			memberDTO.setEmail(request.getParameter("email"));

			int result = memberDAO.join(memberDTO);

			actionForward.setCheck(true);
			actionForward.setPath("../common/result.jsp");

			request.setAttribute("path", "../index.jsp");

			if (result > 0) {
				request.setAttribute("message", "Join Success");
			} else {
				request.setAttribute("message", "Join Fail");
			}

		} else {
			actionForward.setCheck(true);
			actionForward.setPath("./memberJoin.jsp");
		}

		return actionForward;
	}

	public ActionForward login(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward actionForward = new ActionForward();
		String method = request.getMethod();

		//로그인 처리
		if (method.equals("POST")) {

			MemberDTO memberDTO = new MemberDTO();
			memberDTO.setId(request.getParameter("id"));
			memberDTO.setPw(request.getParameter("pw"));
			memberDTO = memberDAO.login(memberDTO);

			// 로그인 성공
			if (memberDTO != null) {
				
				String check = request.getParameter("remember");
				
				//아이디 저장하기
				if(check!=null && check.equals("remember")) {
					Cookie cookie = new Cookie("remember", memberDTO.getId());
					cookie.setPath("/");
					response.addCookie(cookie);
				}
				//아이디 저장 x
				else {
					  Cookie cookie = new Cookie("remember", "");
					  cookie.setPath("/");
					  response.addCookie(cookie);
				}
				
				//session 처리
				HttpSession session = request.getSession();
				session.setAttribute("member", memberDTO);
				
				actionForward.setCheck(false);
				actionForward.setPath("../notice/noticeList.notice");
			} 
			//로그인 실패
			else {
				actionForward.setCheck(false);
				actionForward.setPath("./memberLogin.member");
			}
		}
		//로그인 페이지
		else {
			String id = null;
			Cookie[] cookies = request.getCookies();
			for(Cookie cookie : cookies) {
				if(cookie.getName().equals("remember")) {
					id = cookie.getValue();
				}else {
					id = "";
				}
				request.setAttribute("rememeberId", id);
			}
			
			actionForward.setCheck(true);
			actionForward.setPath("./memberLogin.jsp");

		}
		return actionForward;
	}

	public ActionForward logout(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward actionForward = new ActionForward();

		HttpSession session = request.getSession();
		session.invalidate();
		
		actionForward.setCheck(true);
		actionForward.setPath("../index.jsp");
		
		return actionForward;
	}

	public ActionForward myPage(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward actionForward = new ActionForward();

		actionForward.setCheck(true);
		actionForward.setPath("./memberMyPage.jsp");
		
		return actionForward;
	}

	public ActionForward update(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward actionForward = new ActionForward();

		String method = request.getMethod();
		
		if(method.equals("POST")) {
			
			MemberDTO memberDTO = new MemberDTO();
			memberDTO.setPw(request.getParameter("pw"));
			memberDTO.setName(request.getParameter("name"));
			memberDTO.setAge(Integer.parseInt(request.getParameter("age")));
			memberDTO.setEmail(request.getParameter("email"));
			
			HttpSession session = request.getSession();
			MemberDTO mDto = (MemberDTO)session.getAttribute("member");
			memberDTO.setId(mDto.getId());
			
			int result = memberDAO.update(memberDTO);
			
			if(result>0) {
				session.setAttribute("member", memberDTO); 
			
				actionForward.setCheck(false);
				actionForward.setPath("./memberMyPage.member");
				
			}else {
				actionForward.setCheck(true);
				actionForward.setPath("../index.jsp");
			}
			
		}else {
			actionForward.setCheck(true);
			actionForward.setPath("./memberUpdate.jsp");
		}
		
		return actionForward;
	}

	public ActionForward delete(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward actionForward = new ActionForward();

		HttpSession session = request.getSession();
		MemberDTO memberDTO = (MemberDTO)session.getAttribute("member");
		
		int result = memberDAO.delete(memberDTO);
		
		if(result>0) {
			session.invalidate();		
			
			actionForward.setCheck(false);
			actionForward.setPath("../notice/noticeList.notice");
		}else {
			actionForward.setCheck(false);
			actionForward.setPath("./memberMyPage.member");
		}
		
		return actionForward;
	}

}
