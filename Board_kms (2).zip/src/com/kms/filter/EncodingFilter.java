package com.kms.filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

/**
 * Servlet Filter implementation class EncodingFilter
 */
@WebFilter("/EncodingFilter")
public class EncodingFilter implements Filter {

	String kind;
    /**
     * Default constructor. 
     */
    public EncodingFilter() {
    	//생성자
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		//필터가 종료될때 실행하는 코드
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		//컨트롤러 진입 전
		
		request.setCharacterEncoding(kind);
		response.setCharacterEncoding(kind);
		System.out.println("인코딩 필터 in");
		
		chain.doFilter(request, response);
		//다음 필터의 doFilter를 호출 또는
		//다음 필터가 없으면 controller로 진행
		
		System.out.println("인코딩 필터 out");
		//컨트롤러에서 나갈 때
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		this.kind = fConfig.getInitParameter("kind");
		
	}

}
