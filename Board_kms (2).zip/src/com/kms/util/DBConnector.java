package com.kms.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBConnector {

	public static Connection getConnect() {

		Connection con = null;
	
		// DB 로그인정보 4가지
		String user = "kms";
		String password = "1234";
		String url = "jdbc:oracle:thin:@localhost:1521:orcl";
		String driver = "oracle.jdbc.driver.OracleDriver";
		
		
		try {
			// driver를 메모리에 로딩
			Class.forName(driver);
			
			// 로그인 후 Connection 객체 반환
			con = DriverManager.getConnection(url, user, password);
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			
			System.out.println("DB 드라이버 로딩 실패");
			System.out.println("JDBC를 제대로 추가했는지 확인해주세요.");
			
		} catch (SQLException e) {
			e.printStackTrace();
			
			System.out.println("DB 서버 연결 실패.");
			System.out.println("DB 서버가 접속이 가능한 상태인지 확인.");
			System.out.println("접속 정보를 틀리지 않고 입력했는지 코드 검토.");
		}
		
		return con;
	}
	
	public static void disConnect(PreparedStatement st, Connection con) {
	
		try {
			st.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void disConnect(ResultSet rs, PreparedStatement st, Connection con) {
		
		try {
			rs.close();
			st.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
