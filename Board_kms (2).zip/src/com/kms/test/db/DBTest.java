package com.kms.test.db;

import static org.junit.Assert.*;

import java.sql.Connection;

import org.junit.Test;

import com.kms.board.BoardDTO;
import com.kms.board.notice.NoticeDAO;
import com.kms.util.DBConnector;

public class DBTest {

	private NoticeDAO noticeDAO;
	
	public void test() {
		Connection con = DBConnector.getConnect();
		assertNotNull(con);
	}
	

	@Test
	public void insertTest() throws Exception{
		noticeDAO = new NoticeDAO();
		BoardDTO boardDTO = new BoardDTO();
		boardDTO.setContents("contents");
		boardDTO.setTitle("title");
		boardDTO.setWriter("writer");
		int result = noticeDAO.insert(boardDTO);
		assertEquals(1, result);
		
	}

}
