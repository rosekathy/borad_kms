package com.kms.control;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kms.action.ActionForward;
import com.kms.member.MemberService;

/**
 * Servlet implementation class MemberController
 */
@WebServlet("/MemberController")
public class MemberController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private MemberService memberService;
	
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public MemberController() {
		super();
		memberService = new MemberService();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// 1. 어떤 요청인지 판별
		String command = request.getRequestURI();
		int index = command.lastIndexOf('/');
		command = command.substring(index + 1);

		System.out.println("command : " + command);

		ActionForward actionForward = null;

		// 2. 어떤 서비스의 어떤 메소드
		try {
			if (command.equals("memberJoin.member")) {
				actionForward = memberService.join(request, response);
			} else if (command.equals("memberLogin.member")) {
				actionForward = memberService.login(request, response);
			} else if (command.equals("memberLogout.member")) {
				actionForward = memberService.logout(request, response);
			} else if (command.equals("memberMyPage.member")) {
				actionForward = memberService.myPage(request, response);
			} else if(command.equals("memberUpdate.member")) {
				actionForward = memberService.update(request, response);
			} else if (command.equals("memberDelete.member")){
				actionForward = memberService.delete(request, response);
			}else {
				actionForward = new ActionForward();
			}
		} catch (Exception e) {
		}
		
		if (actionForward.isCheck()) {
			RequestDispatcher view = request.getRequestDispatcher(actionForward.getPath());
			view.forward(request, response);
		} else {
			response.sendRedirect(actionForward.getPath());
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
