package com.kms.control;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kms.action.ActionForward;
import com.kms.board.qna.QnaService;

/**
 * Servlet implementation class QnaController
 */
@WebServlet("/QnaController")
public class QnaController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private QnaService qnaService;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public QnaController() {
        super();
        qnaService = new QnaService();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String command = request.getRequestURI();
		int index = command.lastIndexOf('/');
		command = command.substring(index+1);

		System.out.println("command : "+command);

		ActionForward actionForward = null;
		try {
			if(command.equals("qnaList.qna")) {
				actionForward = qnaService.selectList(request, response);
			}else if(command.contentEquals("qnaContents.qna")) {
				actionForward = qnaService.selectOne(request, response);
			}else if(command.equals("qnaWrite.qna")) {
				actionForward = qnaService.insert(request, response);
			}else if(command.equals("qnaReply.qna")) {
				actionForward = qnaService.reply(request, response);
			}else if(command.equals("qnaUpdate.qna")) {
				actionForward = qnaService.update(request, response);
			}else if(command.equals("qnaDelete.qna")) {
				actionForward = qnaService.delete(request, response);
			}else {
			
			}
		
		}catch (Exception e) {
		}
		
		if(actionForward.isCheck()) {
			RequestDispatcher view = request.getRequestDispatcher(actionForward.getPath());
			view.forward(request, response);
			
		}else {
			response.sendRedirect(actionForward.getPath());
			
		}
	
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
