package com.kms.control;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kms.action.ActionForward;
import com.kms.board.notice.NoticeService;

/**
 * Servlet implementation class NoticeController
 */
@WebServlet("/NoticeController")
public class NoticeController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private NoticeService noticeService;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public NoticeController() {
		super();
		// 1) 생성자에 해도 되고, init 메소드에서 해도 됨
		// noticeService = new NoticeService();
	}

	// 2)
	@Override
	public void init() throws ServletException {
		noticeService = new NoticeService();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// 1. 어떤 요청인지 판별
		String command = request.getRequestURI();
		// System.out.println(command);
		int index = command.lastIndexOf('/');
		command = command.substring(index + 1);
		// System.out.println(command);

		System.out.println("command : " + command);

		ActionForward actionForward = null;

		// 2. 어떤 서비스의 어떤 메소드
		try {
			if (command.equals("noticeWrite.notice")) {
				actionForward = noticeService.insert(request, response);
			} else if (command.equals("noticeList.notice")) {
				actionForward = noticeService.selectList(request, response);
			} else if (command.equals("noticeContents.notice")) {
				actionForward = noticeService.selectOne(request, response);
			} else if (command.equals("noticeUpdate.notice")) {
				actionForward = noticeService.update(request, response);
			} else if (command.equals("noticeDelete.notice")) {
				actionForward = noticeService.delete(request, response);
			} else {
				actionForward = new ActionForward();
			}
		} catch (Exception e) {

		}

		if (actionForward.isCheck()) {
			RequestDispatcher view = request.getRequestDispatcher(actionForward.getPath());
			view.forward(request, response);
		} else {
			response.sendRedirect(actionForward.getPath());
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
