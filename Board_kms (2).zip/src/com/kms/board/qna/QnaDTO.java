package com.kms.board.qna;

import com.kms.board.BoardDTO;

public class QnaDTO extends BoardDTO{

	private int ref; //그룹
	private int step; //그룹 내 순서
	private int depth; //들여쓰기
	
	public int getRef() {
		return ref;
	}
	public void setRef(int ref) {
		this.ref = ref;
	}
	public int getStep() {
		return step;
	}
	public void setStep(int step) {
		this.step = step;
	}
	public int getDepth() {
		return depth;
	}
	public void setDepth(int depth) {
		this.depth = depth;
	}
	
}
