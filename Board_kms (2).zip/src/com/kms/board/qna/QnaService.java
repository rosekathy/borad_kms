package com.kms.board.qna;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kms.action.ActionForward;
import com.kms.board.BoardDTO;
import com.kms.board.BoardService;

public class QnaService implements BoardService{

	private QnaDAO qnaDAO;
	
	public QnaService() {
		qnaDAO = new QnaDAO();
	}
	
	//답글
	public ActionForward reply(HttpServletRequest request, HttpServletResponse response) throws Exception{
		ActionForward actionForward = new ActionForward();

		String method = request.getMethod();

		//답글 등록 처리
		if (method.equals("POST")) {

			QnaDTO qnaDTO = new QnaDTO();
			qnaDTO.setWriter(request.getParameter("writer"));
			qnaDTO.setTitle(request.getParameter("title"));
			qnaDTO.setContents(request.getParameter("contents"));
			qnaDTO.setNum(qnaDAO.getNum());
			
			// 부모의 글번호
			int pNum = Integer.parseInt(request.getParameter("pNum"));
			// 부모의 DTO
			BoardDTO boardDTO = qnaDAO.selectOne(pNum);
			QnaDTO pDto = (QnaDTO) boardDTO;

			// ref
			qnaDTO.setRef(pDto.getRef());

			// step
			qnaDAO.stepUpdate(pDto);
			qnaDTO.setStep(pDto.getStep() + 1);

			// depth
			qnaDTO.setDepth(pDto.getDepth() + 1);

			int result = qnaDAO.reply(qnaDTO);

			//답글 등록 성공
			if(result>0) {
				actionForward.setCheck(false);
				actionForward.setPath("./qnaList.qna");
				
			}
			//답글 등록 실패
			else {
				request.setAttribute("message", "Write Fail");
				request.setAttribute("path", "./qnaList.qna");
				
				actionForward.setCheck(true);
				actionForward.setPath("../common/result.jsp");
			}

		}
		//답글 등록 페이지
		else {
			request.setAttribute("board", "qna");
			
			actionForward.setCheck(true);
			actionForward.setPath("../board/boardReply.jsp");
		}
		
		return actionForward;
	}
	
	
	//원본
	@Override
	public ActionForward insert(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward actionForward = new ActionForward();

		String method = request.getMethod();

		//qna 원글 등록 처리
		if (method.equals("POST")) {
			
			BoardDTO boardDTO = new QnaDTO();
			boardDTO.setWriter(request.getParameter("writer"));
			boardDTO.setTitle(request.getParameter("title"));
			boardDTO.setContents(request.getParameter("contents"));
			boardDTO.setNum(qnaDAO.getNum());

			int result = qnaDAO.insert(boardDTO);

			//글 등록 성공
			if(result>0) {
				actionForward.setCheck(false);
				actionForward.setPath("./qnaList.qna");
				
			}
			//글 등록 실패
			else {
				request.setAttribute("message", "Write Fail");
				request.setAttribute("path", "./qnaList.qna");
				
				actionForward.setCheck(true);
				actionForward.setPath("../common/result.jsp");
			}
			
		} 
		//qna 원글 듵록 페이지
		else {
			request.setAttribute("board", "qna");
			
			actionForward.setCheck(true);
			actionForward.setPath("../board/boardWrite.jsp");
		}

		return actionForward;
	}

	@Override
	public ActionForward update(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward actionForward = new ActionForward();

		String method = request.getMethod();
		
		if(method.equals("POST")) {
			
			QnaDTO qnaDTO = new QnaDTO();
			qnaDTO.setNum(Integer.parseInt(request.getParameter("num")));
			qnaDTO.setTitle(request.getParameter("title"));
			qnaDTO.setWriter(request.getParameter("writer"));
			qnaDTO.setContents(request.getParameter("contents"));
			
			int result = qnaDAO.update(qnaDTO);
			
			actionForward.setCheck(false);
			if(result>0) {
				actionForward.setPath("./qnaList.qna");
				
			}else {
				actionForward.setPath("./qnaUpdate.qna?num="+qnaDTO.getNum());
			}
			
			
		}else {
			int num = Integer.parseInt(request.getParameter("num"));
			QnaDTO qnaDTO = (QnaDTO)qnaDAO.selectOne(num);
			
			request.setAttribute("dto", qnaDTO);
			request.setAttribute("board", "qna");
			
			actionForward.setCheck(true);
			actionForward.setPath("../board/boardUpdate.jsp");
			
		}
		
		return actionForward;
	}

	@Override
	public ActionForward delete(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward actionForward = new ActionForward();

		int num = Integer.parseInt(request.getParameter("num"));
		int result = qnaDAO.delete(num);
		
		if(result>0) {
			actionForward.setCheck(false);
			actionForward.setPath("./qnaList.qna");
			
		}else {
			request.setAttribute("message", "Delete Fail");
			request.setAttribute("path", "./qnaList.qna");
			
			actionForward.setCheck(true);
			actionForward.setPath("../common/result.jsp");
		}

		return actionForward;
	}

	@Override
	public ActionForward selectList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward actionForward = new ActionForward();
		
		//현재 페이지
		int curPage = 1;
		
		try {
			curPage = Integer.parseInt(request.getParameter("curPage"));
		}catch(Exception e) {}
		
		
		String kind = request.getParameter("kind");
		String search = request.getParameter("search");
		if(kind == null){
			kind="title";
		}
		if(search==null){
			search="";
		}
	
		//현재 페이지의 첫번째 글의 row
		int startRow = (curPage-1) * 10 + 1;
		//현재 페이지의 마지막 글의 row
		int lastRow = curPage * 10;
		
		//총 글의 갯수
		int totalCount = 0;
		try {
			totalCount = qnaDAO.getTotal(kind, search);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		//페이지당 글 갯수
		int perPage = 10;
		
		int totalPage = totalCount / perPage;
		if(totalCount%perPage != 0){
			totalPage++;
		}
		
		//한 블럭당 페이지 갯수
		int perBlock = 5;
		//총 블록 갯수
		int totalBlock = totalPage/perBlock;
		if(totalPage%perBlock !=0){
			totalBlock++;
		}
		
		//현재 블럭
		int curBlock = curPage/perBlock;
		if(curPage%perBlock !=0){
			curBlock++;
		}
		
		//현재 블럭에서 첫번째 페이지
		int startNum = (curBlock-1)*perBlock +1;
		//현재 블럭에서 마지막 페이지
		int lastNum = curBlock*perBlock;
		if(curBlock == totalBlock){
			lastNum=totalPage;
		}
		
		
		List<BoardDTO> ar = null;
		try {
			ar = qnaDAO.selectList(startRow, lastRow, kind, search);
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		request.setAttribute("list", ar);
		request.setAttribute("curBlock", curBlock);
		request.setAttribute("totalBlock", totalBlock);
		request.setAttribute("startNum", startNum);
		request.setAttribute("lastNum", lastNum);
		request.setAttribute("kind", kind);
		request.setAttribute("search", search);
		request.setAttribute("board", "qna");
		
		actionForward.setCheck(true);
		actionForward.setPath("../board/boardList.jsp");

		return actionForward;
	}

	@Override
	public ActionForward selectOne(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward actionForward = new ActionForward();

		int num = Integer.parseInt(request.getParameter("num"));
		BoardDTO boardDTO = qnaDAO.selectOne(num);

		request.setAttribute("dto", boardDTO);
		request.setAttribute("board", "qna");

		actionForward.setCheck(true);
		actionForward.setPath("../board/boardContents.jsp");

		return actionForward;
	}

	
	
	
}
