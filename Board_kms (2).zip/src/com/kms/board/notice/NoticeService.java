package com.kms.board.notice;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kms.action.ActionForward;
import com.kms.board.BoardDTO;
import com.kms.board.BoardService;
import com.kms.files.FileDAO;
import com.kms.files.FileDTO;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

public class NoticeService implements BoardService {

	private NoticeDAO noticeDAO;
	private FileDAO fileDAO;
	
	public NoticeService() {
		noticeDAO = new NoticeDAO();
		fileDAO = new FileDAO();
	}

	
	@Override
	public ActionForward insert(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward actionForward = new ActionForward();
		String method = request.getMethod();

		//글 등록
		if (method.equals("POST")) {

			NoticeDTO noticeDTO = new NoticeDTO();
			int maxSize = 1024*1024*100;
			String fileD = request.getServletContext().getRealPath("upload");
			System.out.println("fileD : " + fileD);
			
			File file = new File(fileD);
			if(!file.exists()) {
				file.mkdirs();
			}
			
			MultipartRequest multi = new MultipartRequest(request, fileD, maxSize, "UTF-8", new DefaultFileRenamePolicy());
			
			noticeDTO.setTitle(multi.getParameter("title"));
			noticeDTO.setWriter(multi.getParameter("writer"));
			noticeDTO.setContents(multi.getParameter("contents"));
			noticeDTO.setNum(noticeDAO.getNum());

			
			int result = noticeDAO.insert(noticeDTO);

			System.out.println("result :" + result);
			
			if(result>0) {
				FileDTO fileDTO = new FileDTO();
				fileDTO.setFname(multi.getFilesystemName("f1"));
				fileDTO.setOname(multi.getOriginalFileName("f1"));
				//fileDTO.setNum(noticeDAO.getNum());
				fileDTO.setNum(noticeDTO.getNum());
				
				result = fileDAO.insert(fileDTO);
			}
			
			
			//글 등록 성공
			if (result > 0) {
				actionForward.setCheck(false);
				actionForward.setPath("./noticeList.notice");
			}
			//글 등록 실패
			else {
				request.setAttribute("message", "Write Fail");
				request.setAttribute("path", "./noticeList.notice");
				
				actionForward.setCheck(true);
				actionForward.setPath("../common/result.jsp");
			}
		}
		//글 등록 페이지
		else {
			request.setAttribute("board", "notice");
			
			actionForward.setCheck(true);
			actionForward.setPath("../board/boardWrite.jsp");
		}

		return actionForward;
	}

	@Override
	public ActionForward update(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward actionForward = new ActionForward();

		String method = request.getMethod();
		
		//글 수정
		if(method.equals("POST")) {
			
			NoticeDTO noticeDTO = new NoticeDTO();
			noticeDTO.setNum(Integer.parseInt(request.getParameter("num")));
			noticeDTO.setTitle(request.getParameter("title"));
			noticeDTO.setWriter(request.getParameter("writer"));
			noticeDTO.setContents(request.getParameter("contents"));
			
			int result = noticeDAO.update(noticeDTO);
			
			actionForward.setCheck(false);
			if(result>0) {
				actionForward.setPath("./noticeList.notice");
				
			}else {
				actionForward.setPath("./noticeUpdate.notice?num="+noticeDTO.getNum());
			}
			
		//글 수정 페이지	
		}else {
			int num = Integer.parseInt(request.getParameter("num"));
			NoticeDTO noticeDTO = (NoticeDTO)noticeDAO.selectOne(num);
			
			request.setAttribute("dto", noticeDTO);
			request.setAttribute("board", "notice");
			
			actionForward.setCheck(true);
			actionForward.setPath("../board/boardUpdate.jsp");
			
		}
		
		return actionForward;
	}

	@Override
	public ActionForward delete(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward actionForward = new ActionForward();

		int num = Integer.parseInt(request.getParameter("num"));
		int result = noticeDAO.delete(num);
		
		if(result>0) {
			actionForward.setCheck(false);
			actionForward.setPath("./noticeList.notice");
			
		}else {
			request.setAttribute("message", "Delete Fail");
			request.setAttribute("path", "./noticeList.notice");
			
			actionForward.setCheck(true);
			actionForward.setPath("../common/result.jsp");
		}

		return actionForward;
	}

	@Override
	public ActionForward selectList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward actionForward = new ActionForward();

		//현재 페이지
		int curPage = 1;
		
		try {
			curPage = Integer.parseInt(request.getParameter("curPage"));
		}catch (Exception e) {}
		
		String kind = request.getParameter("kind");
		String search = request.getParameter("search");
		if(kind == null) {
			kind="title";
		}
		if(search == null) {
			search="";
		}
		
		//현재 페이지의 첫번째 글의 row
		int startRow = (curPage-1)*10 + 1;
		//현재 페이지의 마지막 글의 row
		int lastRow = curPage * 10;
		
		//총 글의 갯수
		int totalCount = 0;
		try {
			totalCount = noticeDAO.getTotal(kind, search);
		}catch (Exception e) {}
		
		//페이지당 글 갯수
		int perPage = 10;
		//총 페이지 갯수
		int totalPage = totalCount / perPage;
		if(totalCount % perPage != 0) {
			totalPage++;
		}
		
		//한 블럭당 페이지 갯수
		int perBlock = 5;
		//총 블록 갯수
		int totalBlock = totalPage / perBlock;
		if(totalPage % perBlock != 0) {
			totalBlock++;
		}
		
		//현재 블럭
		int curBlock = curPage/perBlock;
		if(curPage % perBlock != 0) {
			curBlock++;
		}
		
		//현재 블럭에서 첫번째 페이지
		int startNum = (curBlock-1)*perBlock+1;
		//현재 블럭에서 마지막 페이지
		int lastNum = curBlock*perBlock;
		if(curBlock == totalBlock) {
			lastNum=totalPage;
		}
		
		List<BoardDTO> ar = null;
		
		try {
			ar = noticeDAO.selectList(startRow, lastRow, kind, search);
		}catch (Exception e) {
			e.printStackTrace();
		}
				
		request.setAttribute("list", ar);
		request.setAttribute("curBlock", curBlock);
		request.setAttribute("totalBlock", totalBlock);
		request.setAttribute("startNum", startNum);
		request.setAttribute("lastNum", lastNum);
		request.setAttribute("kind", kind);
		request.setAttribute("search", search);
		request.setAttribute("board", "notice");
		
		actionForward.setCheck(true);
		actionForward.setPath("../board/boardList.jsp");
		
		return actionForward;
	}

	@Override
	public ActionForward selectOne(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward actionForward = new ActionForward();

		int num = Integer.parseInt(request.getParameter("num"));
		
		//게시글 정보 가져오기
		BoardDTO boardDTO = noticeDAO.selectOne(num);
		request.setAttribute("dto", boardDTO);
		
		//파일 정보 가져오기
		ArrayList<FileDTO> fileDTO = fileDAO.selectOne(num);
		request.setAttribute("fileDto", fileDTO);

		request.setAttribute("board", "notice");
		
		actionForward.setCheck(true);
		actionForward.setPath("../board/boardContents.jsp");
		
		return actionForward;
	}

}
