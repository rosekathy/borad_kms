package com.kms.board.notice;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.kms.board.BoardDAO;
import com.kms.board.BoardDTO;
import com.kms.util.DBConnector;

public class NoticeDAO implements BoardDAO {

	@Override
	public int insert(BoardDTO boardDTO) throws Exception {

		Connection con = DBConnector.getConnect();
		
		String sql = "insert into notice(num,title,contents,writer,reg_date,hit) values(?,?,?,?,sysdate,0)";

		PreparedStatement st = con.prepareStatement(sql);
		st.setInt(1, boardDTO.getNum());
		st.setString(2, boardDTO.getTitle());
		st.setString(3, boardDTO.getContents());
		st.setString(4, boardDTO.getWriter());

		int result = st.executeUpdate();
		DBConnector.disConnect(st, con);

		return result;
	}

	@Override
	public int update(BoardDTO boardDTO) throws Exception{
		Connection con = DBConnector.getConnect();
		String sql = "update notice set title=?, contents=?, writer=? where num = ?";
		
		PreparedStatement st = con.prepareStatement(sql);
		st.setString(1, boardDTO.getTitle());
		st.setString(2, boardDTO.getContents());
		st.setString(3, boardDTO.getWriter());
		st.setInt(4, boardDTO.getNum());
		
		int result = st.executeUpdate();
		
		DBConnector.disConnect(st, con);
		
		return result;
	}

	@Override
	public int delete(int num) throws Exception{
		Connection con = DBConnector.getConnect();
		String sql = "delete from notice where num = ?";
		
		PreparedStatement st = con.prepareStatement(sql);
		st.setInt(1, num);
		
		int result = st.executeUpdate();
		
		DBConnector.disConnect(st, con);
		
		return result;
	}

	@Override
	public List<BoardDTO> selectList(int startRow, int lastRow, String kind, String search) throws Exception{
		
		Connection con = DBConnector.getConnect();
		
		String sql = "select * from (select rownum R, N.* from (select * from notice where "+kind+" like ? order by num desc) N) where R between ? and ?" ;
		
		PreparedStatement st = con.prepareStatement(sql);
		st.setString(1, "%"+search+"%");
		st.setInt(2, startRow);
		st.setInt(3, lastRow);
		
		ResultSet rs = st.executeQuery();
		
		List<BoardDTO> ar = new ArrayList<BoardDTO>();
		NoticeDTO noticeDTO = null;
		
		while(rs.next()) {
			noticeDTO = new NoticeDTO(); 
			noticeDTO.setNum(rs.getInt("num"));
			noticeDTO.setTitle(rs.getString("title"));
			noticeDTO.setWriter(rs.getString("writer"));
			noticeDTO.setContents(rs.getString("contents"));
			noticeDTO.setReg_date(rs.getString("reg_date"));
			noticeDTO.setHit(rs.getInt("hit"));
			
			ar.add(noticeDTO);
		}
		
		DBConnector.disConnect(rs, st, con);
		
		return ar;
	}

	@Override
	public BoardDTO selectOne(int num) throws Exception{
		Connection con = DBConnector.getConnect();
		String sql = "select * from notice where num = ?";
		PreparedStatement st = con.prepareStatement(sql);
		st.setInt(1, num);

		ResultSet rs = st.executeQuery();
		
		NoticeDTO noticeDTO = null;
		
		if(rs.next()) {
			noticeDTO = new NoticeDTO();
			noticeDTO.setNum(rs.getInt("num"));
			noticeDTO.setTitle(rs.getString("title"));
			noticeDTO.setContents(rs.getString("contents"));
			noticeDTO.setWriter(rs.getString("writer"));
			noticeDTO.setReg_date(rs.getString("reg_date"));
			noticeDTO.setHit(rs.getInt("hit"));
		}
		
		DBConnector.disConnect(rs, st, con);
		
		return noticeDTO;
	}

	@Override
	public int getTotal(String kind, String search) throws Exception{
		
		Connection con = DBConnector.getConnect();
		String sql = "select count(num) from notice where "+kind+ " like ?";
		
		PreparedStatement st = con.prepareStatement(sql);
		st.setString(1, "%"+search+"%");
		
		ResultSet rs = st.executeQuery();
		rs.next();
		
		int result = rs.getInt(1);
		DBConnector.disConnect(rs, st, con);
		
		return result;
	}

	@Override
	public int getNum() throws Exception {
		Connection con = DBConnector.getConnect();
		//dual : 가상의 테이블명, oracle에서 제공, 이름 변경 불가
		String sql = "select notice_seq.nextval from dual";
		
		PreparedStatement st = con.prepareStatement(sql);
		ResultSet rs = st.executeQuery();

		rs.next();
		int result = rs.getInt(1);
		
		return result;
	}

}
