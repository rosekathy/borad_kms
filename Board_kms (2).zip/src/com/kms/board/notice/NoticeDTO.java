package com.kms.board.notice;

import com.kms.board.BoardDTO;

public class NoticeDTO extends BoardDTO{

}
