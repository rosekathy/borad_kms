package com.kms.board;

import java.util.List;

public interface BoardDAO {


	//등록
	public abstract int insert(BoardDTO boardDTO) throws Exception;
	
	//수정
	public abstract int update(BoardDTO boardDTO) throws Exception;
	
	//삭제
	public abstract int delete(int num) throws Exception;
	
	//리스트
	public abstract List<BoardDTO> selectList(int startRow, int lastRow, String kind, String search) throws Exception;
	
	//글하나
	public abstract BoardDTO selectOne(int num) throws Exception;
	
	//totalCount
	public abstract int getTotal(String kind, String search) throws Exception;
	
	//시퀀스번호 받아오기
	public abstract int getNum() throws Exception;
	
}
