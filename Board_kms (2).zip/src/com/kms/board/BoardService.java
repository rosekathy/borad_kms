package com.kms.board;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kms.action.ActionForward;

public interface BoardService {

	//등록 
	public abstract ActionForward insert(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	//수정
	public abstract ActionForward update(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	//삭제
	public abstract ActionForward delete(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	//리스트 전체 조회
	public abstract ActionForward selectList(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	//하나 조회
	public abstract ActionForward selectOne(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	
}
